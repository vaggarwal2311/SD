package com.sd.utility;

import com.sd.dao.CategoryDao;
import com.sd.dao.CategoryImpl;
import com.sd.dao.UserDao;
import com.sd.dao.UserDaoImpl;
import com.sd.models.*;

import java.sql.SQLException;
import java.util.List;
import java.util.Random;

public class Shoppers_DenApp {
    public static void main(String[] args) throws SQLException {
        UserDao userDao = new UserDaoImpl();

        CategoryDao categoryDao = new CategoryImpl();
        categoryDao.addCategory(createCategory());


//        userDao.updateUserName(15, "pawry");
//        try{
//            userDao.deleteUser(80);
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        try{
//            User user = userDao.getUser(51);
//            System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        for(int i=0;i<10;i++) {
//        userDao.addUser(createUser());}
//        try
//        {
//            for(User user : userDao.getAllUsers())
//            {
//                System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
   }

    public static Category createCategory()
    {
        Category category = new Category();
        category.setCid(new Random().nextInt(10));
        category.setCname("abc");
        return category;
    }

    public static User createUser()
    {

            User user = new User();
            user.setPhoneNumber(912345678 + new Random().nextInt(100000));
            user.setAddress("q");
            user.setUserid(new Random().nextInt(100));
            user.setUserName("x");
            user.setAnswer("v");
            user.setEmail("f");
            user.setPassword("h");
            user.setEnabled(0);
            user.setSecurityQuestion("j");
            if (new Random().nextInt(2) == 0) {
                user.setUserRole(UserRole.CUSTOMER);
            } else {
                user.setUserRole(UserRole.ADMIN);
            }
            return user;
        }

}
