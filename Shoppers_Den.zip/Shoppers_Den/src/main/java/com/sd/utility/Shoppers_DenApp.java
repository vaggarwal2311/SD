package com.sd.utility;

import com.sd.dao.*;
import com.sd.models.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;

public class Shoppers_DenApp {
    public static void main(String[] args) throws SQLException {
        UserDao userDao = new UserDaoImpl();
        User user=userDao.getUser(10);
//        ProductDao productDao=new ProductImpl();
//        Product product=productDao.getProductById(62);

//        userDao.addUser(createUser());

//        User user = userDao.getUser(45);
        OrderDao orderDao = new OrderDaoImpl();
//        Order order = orderDao.getOrderById(user,53);
//        orderDao.confirmOrder(user,order);

        for(Order order:orderDao.viewAllOrder(user))
        {
            System.out.println(order);
        }
//        orderDao.placeOrder(user,createOrder());


//        CartDao cartDao = new CartDaoImpl();
//        cartDao.addProduct(user,product,5);
//        product=productDao.getProductById(92);
//        cartDao.addProduct(user,product,2);
//        cartDao.deleteProduct(user,69);
//        cartDao.updateQuantity(user,9,10);
//        cartDao.getAllProducts(user);


//        try
//        {
//            for(User user : userDao.getAllUsers())
//            {
//                System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole()+" "+user.getCart().getCartId());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
//        User user = userDao.getUser(45);
////
//        ProductDao productDao=new ProductImpl();
//        Product product=productDao.getProductById(77);
//        CartDao cartDao = new CartDaoImpl();
//        cartDao.addProduct(user,product,9);

//            CategoryDao categoryDao = new CategoryImpl();
////            Category category=categoryDao.getCategoryById(5);
////            System.out.println(category.getCid()+" "+category.getCname());
//            categoryDao.addCategory(createCategory());

//        ProductDao productDao = new ProductImpl();
//        try
//        {
//            for(Product product : productDao.getAllProducts())
//            {
//                System.out.println(product.getPid()+" "+product.getPname()+" "+product.getQty()+" "+product.getCategory());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
//        for(int i=0;i<5;i++){
//        productDao.addProduct(createProduct());
//        productDao.deleteProduct(33);
//        productDao.updateProductName(69,"kitkat");



//        userDao.updateUserName(15, "pawry");
//        try{
//            userDao.deleteUser(80);
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        try{
//            User user = userDao.getUser(51);
//            System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        for(int i=0;i<10;i++) {
//        userDao.addUser(createUser());}
//        try
//        {
//            for(User user : userDao.getAllUsers())
//            {
//                System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
   }

   public static Product createProduct()
   {
       Product product=new Product();
       product.setDate(LocalDate.now());
       Category c=new Category();
       c.setCid(2);
       product.setCategory(c);
       product.setPdesc("abc");
       product.setPrice(1+new Random().nextInt(10000));
       product.setPid(new Random().nextInt(100));
       product.setPname("cvbn");
       product.setQty(1+new Random().nextInt(10));
       return product;
   }

    public static Category createCategory()
    {
        Category category = new Category();
        category.setCid(new Random().nextInt(10));
        category.setCname("asdf");
        return category;
    }

    public static User createUser()
    {
        User user = new User();
        user.setPhoneNumber(912345678 + new Random().nextInt(100000));
        user.setAddress("qw");
        user.setUserid(new Random().nextInt(100));
        user.setUserName("ad");
        user.setAnswer("z");
        user.setEmail("e");
        user.setPassword("2fg");
        user.setEnabled(0);
        user.setSecurityQuestion("sr");
        if (new Random().nextInt(2) == 0) {
            user.setUserRole(UserRole.CUSTOMER);
        } else {
            user.setUserRole(UserRole.ADMIN);
        }
        Cart cart = new Cart();
        cart.setCartId(new Random().nextInt(100));
        cart.setUser(user);
        user.setCart(cart);
        return user;
    }

    public static Order createOrder()
    {
        Order o = new Order();
        o.setOrderId(new Random().nextInt(100));
        o.setPaymentMode(PaymentMode.Debit);
        o.setStatus(0);
        return o;
    }

}
