package com.sd.utility;

import com.sd.dao.*;
import com.sd.models.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;

public class Shoppers_DenApp {
    public static void main(String[] args) throws SQLException {
//        UserDao userDao = new UserDaoImpl();
//
//        CategoryDao categoryDao = new CategoryImpl();
//        Category category=categoryDao.getCategoryById(5);
//        System.out.println(category.getCid()+" "+category.getCname());
//        categoryDao.addCategory(createCategory());

        ProductDao productDao = new ProductImpl();
        try
        {
            for(Product product : productDao.getAllProducts())
            {
                System.out.println(product.getPid()+" "+product.getPname()+" "+product.getQty()+" "+product.getCategory());
            }
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
//        for(int i=0;i<5;i++){
//        productDao.addProduct(createProduct());}
//        productDao.deleteProduct(33);
//        productDao.updateProductName(69,"kitkat");



//        userDao.updateUserName(15, "pawry");
//        try{
//            userDao.deleteUser(80);
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        try{
//            User user = userDao.getUser(51);
//            System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        for(int i=0;i<10;i++) {
//        userDao.addUser(createUser());}
//        try
//        {
//            for(User user : userDao.getAllUsers())
//            {
//                System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
   }

   public static Product createProduct()
   {
       Product product=new Product();
       product.setDate(LocalDate.now());
       Category c=new Category();
       c.setCid(5);
       product.setCategory(c);
       product.setPdesc("abc");
       product.setPrice(100000);
       product.setPid(new Random().nextInt(100));
       product.setPname("qwe");
       product.setQty(3+new Random().nextInt(10));
       return product;
   }

    public static Category createCategory()
    {
        Category category = new Category();
        category.setCid(new Random().nextInt(10));
        category.setCname("abc");
        return category;
    }

    public static User createUser()
    {

            User user = new User();
            user.setPhoneNumber(912345678 + new Random().nextInt(100000));
            user.setAddress("q");
            user.setUserid(new Random().nextInt(100));
            user.setUserName("x");
            user.setAnswer("v");
            user.setEmail("f");
            user.setPassword("h");
            user.setEnabled(0);
            user.setSecurityQuestion("j");
            if (new Random().nextInt(2) == 0) {
                user.setUserRole(UserRole.CUSTOMER);
            } else {
                user.setUserRole(UserRole.ADMIN);
            }
            return user;
        }

}
