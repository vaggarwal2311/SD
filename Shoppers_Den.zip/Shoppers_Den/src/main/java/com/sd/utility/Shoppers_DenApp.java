package com.sd.utility;

import com.sd.dao.UserDao;
import com.sd.dao.UserDaoImpl;
import com.sd.models.Admin;
import com.sd.models.Customer;
import com.sd.models.User;
import com.sd.models.UserRole;

import java.sql.SQLException;
import java.util.Random;

public class Shoppers_DenApp {
    public static void main(String[] args) throws SQLException {
        UserDao userDao = new UserDaoImpl();
        for(int i=0;i<10;i++) {
        userDao.addUser(createUser());}
    }

    public static User createUser()
    {

            User user = new User();
            user.setPhoneNumber(912345678 + new Random().nextInt(100000));
            user.setAddress("q");
            user.setUserid(new Random().nextInt(100));
            user.setUserName("x");
            user.setAnswer("v");
            user.setEmail("f");
            user.setPassword("h");
            user.setEnabled(0);
            user.setSecurityQuestion("j");
            if (new Random().nextInt(2) == 0) {
                user.setUserRole(UserRole.CUSTOMER);
                Customer c = new Customer();
                c.setCid(new Random().nextInt(100));
                user.setCustomer(c);
            } else {
                user.setUserRole(UserRole.ADMIN);
                Admin a = new Admin();
                a.setA_id(new Random().nextInt(100));
                user.setAdmin(a);
            }
            return user;
        }
}
