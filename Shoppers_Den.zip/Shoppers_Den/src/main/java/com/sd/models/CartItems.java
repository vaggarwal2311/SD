package com.sd.models;

import java.time.LocalDate;

public class CartItems {
    private Cart cart;
    private Product product;
    private LocalDate dateAdded;
    private int quantity;
}
