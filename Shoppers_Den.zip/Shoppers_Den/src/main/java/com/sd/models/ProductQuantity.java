package com.sd.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductQuantity {

    private int productQtyId;

    private Product product;

    private int purchaseQty;

    private long amount;

    private Cart cart;

}
