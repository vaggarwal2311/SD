package com.sd.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Order {
    private int orderId;
    private PaymentMode paymentMode;
    private LocalDate orderDate;
    private Cart cart;
    private int status;
    private long totalPayment;
    private User user;
}
