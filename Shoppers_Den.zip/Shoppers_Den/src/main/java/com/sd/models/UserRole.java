package com.sd.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public enum UserRole {
    ADMIN,CUSTOMER
}
