package com.sd.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product {
    private LocalDate date;
    private String pdesc;
    private int pid;
    private String pname;
    private long price;
    private int qty;
    private int categoryid;
}
