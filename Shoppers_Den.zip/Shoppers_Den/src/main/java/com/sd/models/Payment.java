package com.sd.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Payment {

    private long transactionId;

    private Order order;

    private PaymentMode transactionMode;

    private LocalDate transactionDate;
}
