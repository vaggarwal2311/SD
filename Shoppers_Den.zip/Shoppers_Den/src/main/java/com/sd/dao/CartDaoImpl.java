package com.sd.dao;

import com.sd.helpers.PostgresConnHelper;
import com.sd.models.Product;
import com.sd.models.User;

import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class CartDaoImpl implements CartDao {
    private Connection conn;
    private PreparedStatement ap;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;

    public CartDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }


    @Override
    public void addProduct(User user, Product product,int qty) throws SQLException {
        String addP=resourceBundle.getString("addPinC");
        try
        {
           ap=conn.prepareStatement(addP);
           ap.setInt(1,user.getCart().getCartId());
           ap.setInt(2,product.getPid());
           ap.setDate(3,Date.valueOf(LocalDate.now()));
           ap.setInt(4,qty);
           ap.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void deleteProduct(User user, int productId) throws SQLException {

    }

    @Override
    public void updateQuantity(User user, int productId, int Quantity) throws SQLException {

    }

    @Override
    public void getAllProducts(User user) throws SQLException {

    }
}
