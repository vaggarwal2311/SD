package com.sd.dao;

import com.sd.helpers.PostgresConnHelper;
import com.sd.models.CartItems;
import com.sd.models.Product;
import com.sd.models.User;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;

public class CartDaoImpl implements CartDao {
    private Connection conn;
    private PreparedStatement ap,dpc,upc,gP;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;

    public CartDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }


    @Override
    public void addProduct(User user, Product product,int qty) throws SQLException {
        String addP=resourceBundle.getString("addPinC");
        try
        {
           ap=conn.prepareStatement(addP);
           ap.setInt(1,user.getCart().getCartId());
           ap.setInt(2,product.getPid());
           ap.setDate(3,Date.valueOf(LocalDate.now()));
           ap.setInt(4,qty);
           ap.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void deleteProduct(User user, int productId) throws SQLException {
        int cartId=user.getCart().getCartId();
        String deleteP=resourceBundle.getString("deletePinC");
        dpc=conn.prepareStatement(deleteP);
        dpc.setInt(1,cartId);
        dpc.setInt(2,productId);
        dpc.executeUpdate();
    }

    @Override
    public void updateQuantity(User user, int productId, int Quantity) throws SQLException {
        int cartId=user.getCart().getCartId();
        String updateP=resourceBundle.getString("updatePinC");
        upc=conn.prepareStatement(updateP);
        upc.setInt(1,10);
        upc.setInt(2,cartId);
        upc.setInt(3,productId);
        upc.executeUpdate();
    }

    @Override
    public List<CartItems> getAllProducts(User user) throws SQLException {
        int cartId  = user.getCart().getCartId();
        List<CartItems>cartItemsList=new ArrayList<>();
        Product product=null;
        CartItems cartItems=null;
        ProductDao productDao=new ProductImpl();
        String getAllP=resourceBundle.getString("getAllPinC");
        gP=conn.prepareStatement(getAllP);
        gP.setInt(1,cartId);
        resultSet=gP.executeQuery();
        while (resultSet.next())
        {
            product=productDao.getProductById(resultSet.getInt(2));
//            System.out.println(product.getPid()
//                    +" "+product.getPname()
//                    +" "+product.getPrice()
//                    +" "+product.getCategory().getCname()
//                    +" "+resultSet.getDate(3)
//                    +" "+resultSet.getInt(4));
            cartItems=new CartItems();
            cartItems.setQuantity(resultSet.getInt(4));
            cartItems.setDateAdded(resultSet.getDate(3).toLocalDate());
            cartItems.setProduct(product);
            cartItems.setCart(user.getCart());
            cartItemsList.add(cartItems);
        }
        return cartItemsList;
    }
}
