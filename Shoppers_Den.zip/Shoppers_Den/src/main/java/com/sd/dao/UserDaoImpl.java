package com.sd.dao;

import com.sd.helpers.PostgresConnHelper;
import com.sd.models.Customer;
import com.sd.models.User;
import com.sd.models.UserRole;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;

public class UserDaoImpl implements UserDao{
    private Connection conn;
    private PreparedStatement pu,pc,pa;
    private ResourceBundle resourceBundle;

    public UserDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }


    @Override
    public List<User> getAllUsers() {
        return null;
    }

    @Override
    public void addUser(User user) throws SQLException {
        String adduser=resourceBundle.getString("addUser");
        String addcustomer=resourceBundle.getString("addCustomer");
        String addadmin=resourceBundle.getString("addAdmin");
        try
        {
            pu=conn.prepareStatement(adduser);
            pa=conn.prepareStatement(addadmin);
            pc=conn.prepareStatement(addcustomer);
            pu.setLong(1,user.getPhoneNumber());
            pu.setString(2,user.getUserName());
            pu.setString(3,user.getEmail());
            pu.setString(4,user.getPassword());
            pu.setString(5,user.getAddress());
            pu.setString(6,user.getAnswer());

            if(user.getUserRole().equals(UserRole.ADMIN))
            {
                pu.setInt(7,1);
                pa.setInt(2,user.getUserid());
                pa.setInt(1,user.getAdmin().getA_id());

            }
            else
            {
                pu.setInt(7,2);
                pc.setInt(1,user.getCustomer().getCid());
                pc.setInt(2,user.getUserid());
            }
            pu.setInt(8,user.getUserid());
            pu.setString(9,user.getSecurityQuestion());
            pu.setInt(10,user.getEnabled());

            pu.executeUpdate();
            if(user.getUserRole().equals(UserRole.ADMIN))
            {pa.executeUpdate();}
            else
            {
                pc.executeUpdate();
            }
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public User updateUser(User user, int questionId) {
        return null;
    }

    @Override
    public boolean deleteUser(int userId) {
        return false;
    }

    @Override
    public User getUser(int userid) {
        return null;
    }

    @Override
    public User resetUserPassword(User user) {
        return null;
    }
}
