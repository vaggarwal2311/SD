package com.sd.dao;

import com.sd.helpers.PostgresConnHelper;
import com.sd.models.User;
import com.sd.models.UserRole;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class UserDaoImpl implements UserDao{
    private Connection conn;
    private PreparedStatement pu,pc,pa,du,uun;
    private Statement statement;
    private ResultSet resultSet;
    private ResourceBundle resourceBundle;

    public UserDaoImpl()
    {
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");
    }




    @Override
    public void addUser(User user) throws SQLException {
        String adduser=resourceBundle.getString("addUser");
        String addcustomer=resourceBundle.getString("addCustomer");
        String addadmin=resourceBundle.getString("addAdmin");
        try
        {
            pu=conn.prepareStatement(adduser);
            pa=conn.prepareStatement(addadmin);
            pc=conn.prepareStatement(addcustomer);
            pu.setLong(1,user.getPhoneNumber());
            pu.setString(2,user.getUserName());
            pu.setString(3,user.getEmail());
            pu.setString(4,user.getPassword());
            pu.setString(5,user.getAddress());
            pu.setString(6,user.getAnswer());

            if(user.getUserRole().equals(UserRole.ADMIN))
            {
                pu.setInt(7,1);

            }
            else
            {
                pu.setInt(7,2);
            }
            pu.setInt(8,user.getUserid());
            pu.setString(9,user.getSecurityQuestion());
            pu.setInt(10,user.getEnabled());

            pu.executeUpdate();
            if(user.getUserRole().equals(UserRole.ADMIN))
            {pa.executeUpdate();}
            else
            {
                pc.executeUpdate();
            }
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public List<User> getAllUsers() throws SQLException {
        List<User>userList=new ArrayList<User>();
        User user = null;
        String query = resourceBundle.getString("selectUser");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next())
        {
            user = new User();
            user.setPhoneNumber(resultSet.getInt(1));
            user.setUserName(resultSet.getString(2));
            user.setEmail(resultSet.getString(3));
            user.setPassword(resultSet.getString(4));
            user.setAddress(resultSet.getString(5));
            user.setAnswer(resultSet.getString(6));
            if(resultSet.getInt(7)==1)
            {
                user.setUserRole(UserRole.ADMIN);
            }
            else
            {
                user.setUserRole(UserRole.CUSTOMER);
            }
            user.setUserid(resultSet.getInt(8));
            user.setSecurityQuestion(resultSet.getString(9));
            user.setEnabled(resultSet.getInt(10));
            userList.add(user);
        }
        return userList;
    }

    @Override
    public void updateUserName(int userId, String name) throws SQLException {
        String query = resourceBundle.getString("updateusername");
        uun = conn.prepareStatement(query);
        uun.setString(1,name);
        uun.setInt(2,userId);
        uun.executeUpdate();
    }

    @Override
    public void deleteUser(int userId) throws SQLException {
        String query = resourceBundle.getString("deleteuser");
        du = conn.prepareStatement(query);
        du.setInt(1,userId);
        du.executeUpdate();
    }

    @Override
    public User getUser(int userid) throws SQLException {
        User user = new User();
        String query = resourceBundle.getString("selectUser1");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query+userid);
        while(resultSet.next()) {
            user.setPhoneNumber(resultSet.getInt(1));
            user.setUserName(resultSet.getString(2));
            user.setEmail(resultSet.getString(3));
            user.setPassword(resultSet.getString(4));
            user.setAddress(resultSet.getString(5));
            user.setAnswer(resultSet.getString(6));
            if (resultSet.getInt(7) == 1) {
                user.setUserRole(UserRole.ADMIN);
            } else {
                user.setUserRole(UserRole.CUSTOMER);
            }
            user.setUserid(resultSet.getInt(8));
            user.setSecurityQuestion(resultSet.getString(9));
            user.setEnabled(resultSet.getInt(10));
        }
        return user;
    }
}
