package com.sd.dao;

import com.sd.models.User;

import java.sql.SQLException;
import java.util.List;

public interface UserDao {
    List<User>getAllUsers();
    public void addUser(User user) throws SQLException;
    public User updateUser(User user, int questionId);
    public boolean deleteUser(int userId);
    public User getUser(int userid);
    public User resetUserPassword(User user);
}
