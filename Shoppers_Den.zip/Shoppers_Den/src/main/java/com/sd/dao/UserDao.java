package com.sd.dao;

import com.sd.models.User;

import java.sql.SQLException;
import java.util.List;

public interface UserDao {
    List<User>getAllUsers() throws SQLException;
    public void addUser(User user) throws SQLException;
    public void updateUserName(int userId, String name) throws SQLException;
    public void deleteUser(int userId) throws SQLException;
    public User getUser(int userid) throws SQLException;

}
