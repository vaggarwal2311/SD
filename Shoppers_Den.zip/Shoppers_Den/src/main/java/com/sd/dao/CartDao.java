package com.sd.dao;

import com.sd.models.CartItems;
import com.sd.models.Product;
import com.sd.models.User;

import java.sql.SQLException;
import java.util.List;

public interface CartDao {
    public void addProduct(User user, Product product, int qty) throws SQLException;
    public void deleteProduct(User user, int productId) throws SQLException;
    public void updateQuantity(User user, int productId, int Quantity) throws SQLException;
    public List<CartItems> getAllProducts(User user) throws SQLException;

}
