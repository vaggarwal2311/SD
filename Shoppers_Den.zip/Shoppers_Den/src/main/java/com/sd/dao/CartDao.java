package com.sd.dao;

import com.sd.models.Product;
import com.sd.models.User;

import java.sql.SQLException;

public interface CartDao {
    public void addProduct(User user, Product product, int qty) throws SQLException;
    public void deleteProduct(User user, int productId) throws SQLException;
    public void updateQuantity(User user, int productId, int Quantity) throws SQLException;
    public void getAllProducts(User user) throws SQLException;

}
