package com.sd.utility;

import com.sd.dao.*;
import com.sd.models.*;


import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Shoppers_DenAppCustomer {
    private static final Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws SQLException {

        //User
        User user=null;

        //Login variable
        boolean correct = false;

        //Order
        Order order=null;

        //UserDao
        UserDao userDao = new UserDaoImpl();
        //CartItems
        CartDao cartDao=new CartDaoImpl();
        //Order
        OrderDao orderDao=new OrderDaoImpl();
        //Products
        ProductDao productDao=new ProductImpl();
        //login
        LoginDao login=new LoginImpl();

        System.out.println();
        loop:while(true) {
            System.out.println("Welcome to Shoppers_Den");
            System.out.println("1 - Login");
            System.out.println("2 - Register");
            System.out.println("3 - Exit");
            String way = sc.nextLine();
            switch (way.toLowerCase()) {
                case "login":
                    System.out.println("Enter your userId");
                    int id = Integer.parseInt(sc.nextLine());
                    System.out.println("Enter your password");
                    String pass = sc.nextLine();
                    if (login.check(id, pass)) {
                        user = userDao.getUser(id);
                        correct=true;
                    } else  {
                        System.out.println("Enter a valid id or pass");
                        continue loop;
                    }
                    break loop;
                case "register":
                    user = createUser();
                    userDao.addUser(user);
                    System.out.println("You have been successfully registered with Login Id : " + user.getUserid());
                    continue loop;
                case "exit":
                    System.exit(0);
            }
        }
        if(correct) {
            System.out.println("You have been logged in with user id : " + user.getUserid());
            System.out.println("Welcome " + user.getUserName());
            shopping:
            while (true) {
                System.out.println("1 - View All Products ");
                System.out.println("2 - Add to Cart ");
                System.out.println("3 - Place Order ");
                System.out.println("4 - Confirm Order");
                System.out.println("5 - Update Profile ");
                System.out.println("6 - View Profile ");
                System.out.println("7 - Cancel Order");
                System.out.println("8 - View Products in Cart");
                System.out.println("9 - Order History");
                System.out.println("10 - View Placed Order");
                System.out.println("11 - Delete Profile");
                System.out.println("12 - Logout and exit");
                System.out.println("13 - Show Order Items ");
                System.out.println("Enter your choice ");
                int c = Integer.parseInt(sc.nextLine());
                switch (c) {
                    case 1:
                        for (Product product : productDao.getAllProducts())
                            System.out.println(product.getPid()
                                    + " " + product.getPname()
                                    + " " + product.getPrice()
                                    + " " + product.getPdesc());
                        continue shopping;
                    case 2:
                        System.out.println("Enter product id");
                        int pid = Integer.parseInt(sc.nextLine());
                        System.out.println("Enter quantity");
                        int q = Integer.parseInt(sc.nextLine());
                        cartDao.addProduct(user, pid, q);
                        System.out.println("Given product has been added successfully ");
                        continue shopping;
                    case 3:
                        order = createOrder();
                        orderDao.placeOrder(user, order);
                        System.out.println("Your order has been placed successfully ");
                        System.out.println("Your order is " + order.getOrderId());
                        continue shopping;
                    case 4:
                        System.out.println("Enter your oder id ");
                        int oid = Integer.parseInt(sc.nextLine());
                        orderDao.confirmOrder(user, oid);
                        System.out.println("Your order with order id " + oid + " has been successfully confirmed ");
                        continue shopping;
                    case 5:
                        System.out.println("You are in update profile section ");
                        System.out.println("Enter your updated name");
                        String n = sc.nextLine();
                        userDao.updateUserName(user.getUserid(), n);
                        System.out.println("Your name has been updated successfully ");
                        continue shopping;
                    case 6:
                        System.out.println("Your credentials are ");
                        System.out.println("Your user id is " + user.getUserid()
                                + " " + "Your name is " + user.getUserName()
                                + " " + "Your phone number is " + user.getPhoneNumber()
                                + " " + "Your email is " + user.getEmail());
                        System.out.println("Your orders are ");
                        for (Order order1 : orderDao.viewAllOrder(user)) {
                            System.out.println("Your order id is " + order1.getOrderId()
                                    + " " + "Your total amount is " + order1.getTotalPayment()
                                    + " " + "Your mode is " + order1.getPaymentMode());
                        }
                        continue shopping;
                    case 7:
                        System.out.println("Enter the id of the order you want to cancel ");
                        int id = Integer.parseInt(sc.nextLine());
                        orderDao.cancelOrder(id);
                        System.out.println("Your order has been canceled successfully ");
                        continue shopping;
                    case 8:
                        System.out.println("Your cart items ");
                        for (CartItems cartItems : cartDao.getAllProducts(user)) {
                            System.out.println(cartItems.getProduct().getPname()
                                    + " " + cartItems.getQuantity() + " " + cartItems.getProduct().getPrice());
                        }
                        continue shopping;
                    case 9:
                        System.out.println("Your order history is ");
                        for (Order order1 : orderDao.viewAllOrder(user)) {
                            System.out.println("Your order id is " + order1.getOrderId()
                                    + " " + "Your total amount is " + order1.getTotalPayment()
                                    + " " + "Your mode is " + order1.getPaymentMode());
                        }
                        continue shopping;
                    case 10:
                        System.out.println("Your placed order is ");
                        System.out.println("Enter your oder id ");
                        int od = Integer.parseInt(sc.nextLine());
                        order = orderDao.getOrderById(user, od);
                        System.out.println(order.getOrderId() + " " + order.getTotalPayment() + " " + order.getStatus());
                        continue shopping;
                    case 11:
                        userDao.deleteUser(user.getUserid());
                        System.out.println("Your profile has been successfully deleted ");
                        System.exit(0);
                    case 12:
                        System.out.println("You have been successfully logged out ");
                        System.exit(0);
                    case 13:
                        System.out.println("Enter the order id ");
                        int orderid = Integer.parseInt(sc.nextLine());
                        List<Product> productList = orderDao.showOrderItems(orderid);
                        System.out.println(productList);
                        continue shopping;
                    default:
                        break shopping;
                }
            }
        }

        System.out.println("Thank you for shopping with Shoppers_Den");






//        UserDao userDao = new UserDaoImpl();
//        User user=userDao.getUser(10);
////        ProductDao productDao=new ProductImpl();
////        Product product=productDao.getProductById(62);
//
////        userDao.addUser(createUser());
//
////        User user = userDao.getUser(45);
//        OrderDao orderDao = new OrderDaoImpl();
////        Order order = orderDao.getOrderById(user,53);
////        orderDao.confirmOrder(user,order);
//
//        for(Order order:orderDao.viewAllOrder(user))
//        {
//            System.out.println(order.getOrderId()+" "+order.getUser().getUserid());
//        }
//        orderDao.placeOrder(user,createOrder());


//        CartDao cartDao = new CartDaoImpl();
//        cartDao.addProduct(user,product,5);
//        product=productDao.getProductById(92);
//        cartDao.addProduct(user,product,2);
//        cartDao.deleteProduct(user,69);
//        cartDao.updateQuantity(user,9,10);
//        cartDao.getAllProducts(user);


//        try
//        {
//            for(User user : userDao.getAllUsers())
//            {
//                System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole()+" "+user.getCart().getCartId());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
//        User user = userDao.getUser(45);
////
//        ProductDao productDao=new ProductImpl();
//        Product product=productDao.getProductById(77);
//        CartDao cartDao = new CartDaoImpl();
//        cartDao.addProduct(user,product,9);

//            CategoryDao categoryDao = new CategoryImpl();
////            Category category=categoryDao.getCategoryById(5);
////            System.out.println(category.getCid()+" "+category.getCname());
//            categoryDao.addCategory(createCategory());

//        ProductDao productDao = new ProductImpl();
//        try
//        {
//            for(Product product : productDao.getAllProducts())
//            {
//                System.out.println(product.getPid()+" "+product.getPname()+" "+product.getQty()+" "+product.getCategory());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }
//        for(int i=0;i<5;i++){
//        productDao.addProduct(createProduct());
//        productDao.deleteProduct(33);
//        productDao.updateProductName(69,"kitkat");



//        userDao.updateUserName(15, "pawry");
//        try{
//            userDao.deleteUser(80);
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        try{
//            User user = userDao.getUser(51);
//            System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//        }
//        catch(SQLException e){
//            System.out.println(e.getMessage());
//        }
//        for(int i=0;i<10;i++) {
//        userDao.addUser(createUser());}
//        try
//        {
//            for(User user : userDao.getAllUsers())
//            {
//                System.out.println(user.getUserid() +" "+ user.getUserName()+" "+user.getUserRole());
//            }
//        }
//        catch (SQLException e)
//        {
//            System.out.println(e.getMessage());
//        }

   }

   public static Product createProduct()
   {
       Product product=new Product();
       product.setDate(LocalDate.now());
       Category c=new Category();
       c.setCid(2);
       product.setCategory(c);
       product.setPdesc("abc");
       product.setPrice(1+new Random().nextInt(10000));
       product.setPid(new Random().nextInt(100));
       product.setPname("cvbn");
       product.setQty(1+new Random().nextInt(10));
       return product;
   }

    public static Category createCategory()
    {
        Category category = new Category();
        category.setCid(new Random().nextInt(10));
        category.setCname("asdf");
        return category;
    }

    public static User createUser()
    {
        User user = new User();
        System.out.println("Enter your phone number ");
        user.setPhoneNumber(Long.parseLong(sc.nextLine()));
        System.out.println("Enter your address ");
        user.setAddress(sc.nextLine());
        user.setUserid(new Random().nextInt(1000000000));
        System.out.println("Enter your username ");
        user.setUserName(sc.nextLine());
        System.out.println("Enter your security answer ");
        user.setAnswer(sc.nextLine());
        System.out.println("Enter your email ");
        user.setEmail(sc.nextLine());
        System.out.println("Enter your password ");
        user.setPassword(sc.nextLine());
        user.setEnabled(1);
        System.out.println("Enter your security question ");
        user.setSecurityQuestion(sc.nextLine());
        user.setUserRole(UserRole.CUSTOMER);
        Cart cart = new Cart();
        cart.setCartId(new Random().nextInt(100));
        cart.setUser(user);
        user.setCart(cart);
        return user;
    }

    public static Order createOrder() {
        Order o = new Order();
        o.setOrderId(new Random().nextInt(10000));
        System.out.println("Enter payment mode");
        String mode = sc.nextLine();
        if (mode.equalsIgnoreCase("Debit"))
        {
            o.setPaymentMode(PaymentMode.Debit);
        }
        else if(mode.equalsIgnoreCase("Credit"))
        {
            o.setPaymentMode(PaymentMode.Credit);
        }
        else
        {
            o.setPaymentMode(PaymentMode.UPI);
        }
        o.setStatus(0);
        return o;
    }

}
