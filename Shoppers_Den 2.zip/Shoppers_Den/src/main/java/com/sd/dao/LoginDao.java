package com.sd.dao;

import java.sql.SQLException;

public interface LoginDao {
    boolean check(int userId, String pass) throws SQLException;
}
