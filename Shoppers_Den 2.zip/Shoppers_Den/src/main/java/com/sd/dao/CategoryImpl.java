package com.sd.dao;
import com.sd.helpers.PostgresConnHelper;
import com.sd.models.Category;
import com.sd.models.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
public class CategoryImpl implements CategoryDao {
    private Connection conn;
    private ResourceBundle resourceBundle;
    private Statement statement;
    private ResultSet resultSet;
    private PreparedStatement p1,du,uun,getcat;

    public CategoryImpl(){
        conn= PostgresConnHelper.getConnection();
        if(conn!=null)
        {
            System.out.println("Connection Established...");
        }
        else
        {
            System.out.println("Connection has issue...");
        }
        resourceBundle=ResourceBundle.getBundle("db");

        }

    @Override
    public void addCategory(Category category){
        String addCategory = resourceBundle.getString("addc");
        try {
            p1 = conn.prepareStatement(addCategory);
            p1.setInt(1, category.getCid());
            p1.setString(2, category.getCname());
            p1.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public List<Category> getAllCategories() throws SQLException {
        conn=PostgresConnHelper.getConnection();
        String query=null;
        List<Category> categoryList=null;
        Category category=null;
        categoryList=new ArrayList<Category>();
        query=resourceBundle.getString("selectcat");
        statement=conn.createStatement();
        resultSet=statement.executeQuery(query);
        while(resultSet.next()){
            category=new Category();
            category.setCid(resultSet.getInt(1));
            category.setCname(resultSet.getString(2));

            categoryList.add(category);
        }
        return categoryList;
    }
    @Override
    public Category getCategoryById(int categoryId) throws SQLException {
        Category category = new Category();
        String query = resourceBundle.getString("getc");
        statement = conn.createStatement();
        resultSet=statement.executeQuery(query+categoryId);
        while(resultSet.next())
        {
            category.setCid(resultSet.getInt(1));
            category.setCname(resultSet.getString(2));
        }
        return category;
    }

    @Override
    public void deleteCategory(int categoryId) throws SQLException {
        String query = resourceBundle.getString("deletecat");
        du = conn.prepareStatement(query);
        du.setInt(1, categoryId);
        du.executeUpdate();

    }

    @Override
    public void updateCategory(int cId, String name) throws SQLException {
        String query = resourceBundle.getString("updatecat");
        uun = conn.prepareStatement(query);
        uun.setInt(2,cId);
        uun.setString(1,name);
        uun.executeUpdate();
    }
}